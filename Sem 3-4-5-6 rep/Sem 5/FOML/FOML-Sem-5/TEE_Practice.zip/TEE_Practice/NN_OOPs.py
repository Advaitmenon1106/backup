class layer:
    def __init__(self, activation, neurons=None):
        self.neurons = neurons
        self.activation = activation